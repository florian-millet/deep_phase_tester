import numpy as np

deg_to_rad = np.arccos(-1)/180
radius     = 6371

def end_point(lat1,lon1,brng,dist):
    ca1     = np.cos( lat1 * deg_to_rad )
    sa1     = np.sin( lat1 * deg_to_rad )
    cd      = np.cos( dist / radius )
    sd      = np.sin( dist / radius )
    cth     = np.cos( brng * deg_to_rad )
    sth     = np.sin( brng * deg_to_rad )
    end_lat = np.arcsin( sa1*cd + ca1*sd*cth )
    sa2     = np.sin( end_lat )
    end_lon = lon1 + np.arctan2( sth*sd*ca1 , cd-sa1*sa2 ) / deg_to_rad
    return end_lat / deg_to_rad, end_lon
