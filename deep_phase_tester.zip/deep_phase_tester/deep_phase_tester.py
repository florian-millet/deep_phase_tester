#!/usr/bin/python3
########################################################
##                                                    ##
##                                                    ##
##    Create look-up table for suitable geometries    ##
##                                                    ##
##                                                    ##
########################################################


#~~~~~~~~~~~~~~~~~~#
#                  #
#  Initialisation  #
#                  #
#~~~~~~~~~~~~~~~~~~#

# Python libraries
import modules.utils as geod
import numpy         as np
import gc
import os
import sys
import glob
import time
import warnings
import subprocess
import instaseis
import obspy
from   obspy.taup import TauPyModel
from   obspy      import geodetics
from   mpl_toolkits.basemap import Basemap
from   matplotlib.colors    import LinearSegmentedColormap
from   matplotlib.gridspec  import GridSpec

# Pyplot does weird things sometimes...
import matplotlib
matplotlib.use('Agg')
from   matplotlib        import pyplot as plt
from   matplotlib.ticker import MaxNLocator

# Obspy for station / event downloads
from   obspy.clients.fdsn import Client
from   obspy.clients.fdsn import RoutingClient
from   obspy              import UTCDateTime
from   obspy              import read
from   obspy              import read_inventory
from   obspy              import read_events

# Radiation patterns
from   obspy.imaging.beachball import mt2plane
from   obspy.imaging.beachball import MomentTensor as MomTen
import modules.radiation       as     radiation    # From Li

# Annoying user warnings
warnings.simplefilter(action='ignore', category=UserWarning)



#~~~~~~~~~~~#
#           #
#  Options  #
#           #
#~~~~~~~~~~~#

# What to do
from_disk = True  #False #      If data are already downloaded, simply pull from file
only_dl   = False #True  #      Stops the execution after the download of the data (continues to next event)
proc_yn   = False #True  #      Whether to process the data
synt_yn   = False #True  #      Whether to compute the synthetics or not (not doing so may conflict with plots)
maps_yn   = True  #False #      Whether to plot the data or not
rid_rit   = True  #False #      Resets and populates the cmt solution folder (needs to be True when adding new events)
simple_in = True  #False #      Uses a simple input file for source-receiver geometry, only for Sdiff, no region in particular

# Tree looks like that
# >rid_rit
# >loop source cells
#   >check amongst CMTs
#   >loop events
#     >from_disk or download [xml]
#     >check station number
#       >proc_yn
#         >only_dl (break)
#       >synt_yn
#       >maps_yn
# >done

# Just for testing purposes
test_yn = False #True #
test_ar = ''    #'CA'
remv_ar = []
keep_ar = []

# Folders
inp_fo = 'inputs/'
plt_fo = 'plots/'
dat_fo = 'data/'
cmt_fo = 'cmt/'
wor_fo = 'working_directory/'
sub_fo = '01/'
low_fo = 'low_res/'

# Load instaseis Green functions
gf_dat  = instaseis.open_db("syngine://prem_a_2s")
dat_typ = "DISP"            # Type of output from remove_response
syn_typ = 'displacement'    # Type of output from the synthetics

# I/O, phase and region
geom_f = inp_fo + 'example_simple_input.txt'  #'output_PER_5x5x1_d-c-K-P.txt'
cmt_fi = cmt_fo + 'example_cmt_selection.txt' #'CMT_mag_5-8_dep_100.txt'
phofin = 'Sdiff'    # Not used in simple input mode
poi_nb = -1         # Not used in simple input mode
rgofin = 'PER'      # Not used in simple input mode
roi_nb = -1         # Not used in simple input mode

# Client parameters
Sclient = Client("IRIS")                  # Used to download event data, not handled by RoutingClient
Rclient = RoutingClient("iris-federator") # Used to download station data and waveforms
timess  = [UTCDateTime("1980-01-01"), UTCDateTime("2021-01-01")]
mod     = TauPyModel("prem") #("ak135") #
modcmb  = 2891.0 #PREM -- 2891.5 #AK135 --
magnit  = [5.0, 8.0]
depths  = [  0,2900]
angles  = [  0,  90]    # Not used in simple input mode
min_st  =  0            # Minimum number of station to show up
max_st  = 20            # Minimum number of stations to be processed
s_rate  = 10            # Final sampling rate of waveforms
f_mini  = 0.03          # Lowest frequency for basic filtering

# Plot parameters
deldep  = 150           # Distance above CMB for raypath (plot only)
map_lat = 52            # Not used in simple input mode
map_lon = 53            # Not used in simple input mode
ph_plt  = ['Sdiff', 'SKS', 'SKKS']
f_plot  = [0.03, 0.1]   # Corner frequencies for plots
factor  = 3.            # Amplification factor for plots
x_lims  = [-20,80]      # Time axis limits for plots

# Vote map colorscale
RGBv = [( 0.6         , 0.79221968 , 1.         , 1.        ),
        ( 1.          , 1.         , 0.6        , 1.        ),
        ( 0.85781155  , 1.         , 0.6        , 1.        ),
        ( 0.6         , 0.85662    , 1.         , 1.        ),
        ( 0.6         , 1.         , 0.77629329 , 1.        ),
        ( 0.96974816  , 1.         , 0.6        , 1.        ),
        ( 1.          , 0.6        , 0.6        , 1.        ),
        ( 0.88571429  , 0.71428571 , 0.76226992 , 1.        ),
        ( 0.88571429  , 0.72222238 , 0.71428571 , 1.        ),
        ( 1.          , 0.72330653 , 0.6        , 1.        ),
        ( 0.66666667  , 0.75386556 , 0.93333333 , 1.        ),
        ( 0.88571429  , 0.88020846 , 0.71428571 , 1.        ),
        ( 0.71428571  , 0.79914494 , 0.88571429 , 1.        ),
        ( 0.83658813  , 0.86666667 , 0.73333333 , 1.        ),
        ( 1.          , 0.97467711 , 0.6        , 1.        ),
        ( 0.83691882  , 0.71428571 , 0.88571429 , 1.        ),
        ( 1.          , 0.87669347 , 0.6        , 1.        ),
        ( 0.85        , 0.75       , 0.7659636  , 1.        ),
        ( 0.86666667  , 0.80026072 , 0.73333333 , 1.        ),
        ( 0.93333333  , 0.66666667 , 0.68210604 , 1.        ),
        ( 1.          , 0.62532289 , 0.6        , 1.        )]
RGBl = LinearSegmentedColormap.from_list('RGBl',RGBv,N=len(RGBv))


#-----------------------------------#
# Create relevant folder structures #
#-----------------------------------#
 
# Plots
if not os.path.exists(plt_fo + sub_fo):
    os.makedirs(plt_fo + sub_fo)



#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                               #
#  Load information for events  #
#                               #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

#----------#
# Vote map #
#----------#

cl_f = inp_fo + 'clustering_01.txt'
filz = open(cl_f)
head = filz.readline().split()
filz.close()
mdim = [int(int(head[2])*2), int(head[4])]
clst = np.loadtxt(cl_f,skiprows=1)
ratm = np.append((clst[:,0].copy()    ), (clst[:,0].copy()))
rotm = np.append((clst[:,1].copy()-360), (clst[:,1].copy())) #+180)%360-180
mlay = np.append((clst[:,2].copy()    ), (clst[:,2].copy())) #+180)%360-180


#---------------#
# CMT solutions # (individual files are created from larger file and used in synthetics and plots)
#---------------#

# Clear working folder
if rid_rit:
    try:
        for f in glob.glob(cmt_fo + wor_fo + '*'):
            os.remove(f)
    except Exception as e:
        pass

# Prepare stuff
ev_lis = np.array([0,0,0,0,0,0,0,0])
if rid_rit:
    cur_fi = open('temp.txt','w')

# Read file
with open(cmt_fi) as cmt_so:
    cmt_da = cmt_so.readlines()
    for cmt_li in cmt_da:

        # Empty lines
        if len(cmt_li) < 2 :
            continue

        # Detect next event
        if len(cmt_li) > 40:

            # Close old file
            if rid_rit:
                cur_fi.close()
            cmt_in = cmt_li.split()

            # Add location info to list
            ev_lis = np.vstack((ev_lis, np.array([float(cmt_in[7]), float(cmt_in[8]), float(cmt_in[9]),
                                                    int(cmt_in[1]),   int(cmt_in[2]),   int(cmt_in[3]),
                                                    int(cmt_in[4]),   int(cmt_in[5])])))
            ev_tim = int( int(cmt_in[1]) * 1e08 + int(cmt_in[2]) * 1e06 + int(cmt_in[3]) * 1e4  + \
                          int(cmt_in[4]) * 1e2  + int(cmt_in[5]) * 1e0  )

            # Open new file
            if rid_rit:
                cur_fi = open(cmt_fo + wor_fo + 'CMT_' + str(ev_tim), 'w')

        # Write individual files in working folder
        if rid_rit:
            cur_fi.write(cmt_li)

# Finalize 
if rid_rit:
    cur_fi.close()
    os.remove('temp.txt')
ev_lis = np.delete(ev_lis, (0), 0)


#------------------#
# geom_loop header # (simple input is at the end)
#------------------#

if not simple_in:

    # read headers
    g_file = open(geom_f)
    g_phas = g_file.readline().split()
    g_regi = g_file.readline().split()
    g_reso = g_file.readline().split()
    g_reso = [int(val) for val in g_reso]
    g_file.close()

    # check for phase of interest
    for i in range(len(g_phas)):
        if g_phas[i] == phofin:
            poi_nb = i
    if poi_nb == -1:
        sys.exit('Phase not found')

    # check for region of interest
    for i in range(len(g_regi)):
        if g_regi[i] == rgofin:
            roi_nb = i
    if roi_nb == -1:
        sys.exit('Region not found')


#-------------------------------#
# Find all potential geometries #
#-------------------------------#

    # load all geometries
    allgeo = np.loadtxt(geom_f, skiprows=4)
    
    # restrict to phase and region of interest
    allgeo = allgeo[ allgeo[:, 0] == poi_nb    ]
    allgeo = allgeo[ allgeo[:, 1] == roi_nb    ]
    allgeo = allgeo[ allgeo[:,12] >= angles[0] ]
    allgeo = allgeo[ allgeo[:,12] <= angles[1] ]
    
    # separate events and remove duplicates
    all_ev = allgeo[:,2:5]
    all_ev = [tuple(row) for row in all_ev]
    all_ev = np.unique(all_ev, axis=0)
    
    # station range for every event
    all_st = []
    for i in range(len(all_ev)):
        temp_a = allgeo[ allgeo[:,2] == all_ev[i,0] ]
        temp_a = temp_a[ temp_a[:,3] == all_ev[i,1] ]
        temp_a = temp_a[:,5:7]
        all_st.append(np.array(temp_a))
    all_st = np.array(all_st)


#---------------------------------------#
# Simple input for potential geometries #
#---------------------------------------#

if simple_in:

    #g_reso defines the additional NSEW padding to find events and stations from center of search area
    g_file = open(geom_f)
    g_temp = g_file.readline().split()
    g_reso = int(g_file.readline().split()[0])
    g_reso = [g_reso, g_reso]
    g_file.close()

    #all_ev are all the event "cells" location
    allgeo = np.loadtxt(geom_f, skiprows=4, usecols=[0,1,2,3,4])
    all_ev = allgeo[:,:3]
    all_ev = [tuple(row) for row in all_ev]
    all_ev = np.unique(all_ev, axis=0)

    #all_st are all the location "cells" for every event
    all_st = []
    for i in range(len(all_ev)):
        temp_a = allgeo[ allgeo[:,0] == all_ev[i,0] ]
        temp_a = temp_a[ temp_a[:,1] == all_ev[i,1] ]
        temp_a = temp_a[:,3:5]
        all_st.append(np.array(temp_a))
    all_st = np.array(all_st)



#~~~~~~~~~~~~~#
#             #
#  Main loop  #
#             #
#~~~~~~~~~~~~~#


#----------------------------------------#
# Loop through all potential event cells #
#----------------------------------------#

print()
for i in range(len(all_ev)): 
    if i < 0:
        continue
    if i > 100:
        continue
    starts  = time.time()
    src_cat = []
    cur_cat = []

    # Loop over all events from CMT solution list
    for j in range(len(ev_lis)):

        # Check whether event is in current cell
        if ( (ev_lis[j,0] > all_ev[i,0]-(g_reso[0]/2.)) and \
             (ev_lis[j,0] < all_ev[i,0]+(g_reso[0]/2.)) and \
             (ev_lis[j,1] > all_ev[i,1]-(g_reso[0]/2.)) and \
             (ev_lis[j,1] < all_ev[i,1]+(g_reso[0]/2.)) ):

            # Try to download its info on IRIS
            try:
                start_t = UTCDateTime(str(int(ev_lis[j,3]))+'-'+ str(int(ev_lis[j,4]))+'-'+ str(int(ev_lis[j,5]))+'T'+ \
                                      str(int(ev_lis[j,6]))+':'+ str(int(ev_lis[j,7])))
                cur_cat = Sclient.get_events(starttime    = start_t       , endtime      = start_t+100   ,
                                             minmagnitude = magnit[0]     , maxmagnitude = magnit[1]     ,
                                             mindepth     = ev_lis[j,2]-50, maxdepth     = ev_lis[j,2]+50,
                                             latitude     = ev_lis[j,0]   , longitude    = ev_lis[j,1]   ,
                                             maxradius    = .1)

                # Append info to list of events for current cell
                if src_cat == []:
                    src_cat = cur_cat
                else:
                    src_cat.extend(cur_cat)
            except Exception as e:
                print(e)
                pass

    # Go to next cell if no event found
    if src_cat == []:
        print(i+1,'/',len(all_ev), end='', flush=True)
        print('    No event found for location',
              all_ev[i,0],all_ev[i,1],'within +-',g_reso[0]/2.)
        continue

    # Talk to the crowd
    print(i+1,'/',len(all_ev), end='', flush=True)
    print('    There were',len(src_cat),'events for location',
          all_ev[i,0],all_ev[i,1],'within +-',g_reso[0]/2., end='')


#--------------------------------------------------#
# Find all active receivers for all events in cell #
#--------------------------------------------------#

    temp    = np.array(all_st[i])
    latitu  = [np.min(temp[:,0]),np.max(temp[:,0])]
    longit  = [np.min(temp[:,1]),np.max(temp[:,1])]
    print('  (  lat',str(latitu[0])+'~'+str(latitu[1]),
             '  lon',str(longit[0])+'~'+str(longit[1]), ' )')

    # Loop over list of events for current cell
    for j in range(len(src_cat)):
        times2  = [ src_cat[j].origins[0].time - 30 , 
                    src_cat[j].origins[0].time + 30 ]

        # Download (or load) stations from the routing client
        try:
            f_nam3 = dat_fo + str(src_cat[j].origins[0].time)[:19] + '.xml'
            if from_disk:
                rec_cat = read_inventory(f_nam3)

            # Ask for all broadband and high-broadband stations (Z,N,E as well as 1,2,3)
            else:
                ch_sel  = "B??,H??"
                rec_cat = Rclient.get_stations(network      = "*"       , station = "*"       , 
                                               channel      = ch_sel    , level   = "response",
                                               starttime    = times2[0] , endtime = times2[1] , 
                                               minlatitude  = max( -89.9, latitu[0]-(g_reso[0]*2.)),  
                                               maxlatitude  = min(  89.9, latitu[1]+(g_reso[0]*2.)),
                                               minlongitude = max(-179.9, longit[0]-(g_reso[1]*2.)),
                                               maxlongitude = min( 179.9, longit[1]+(g_reso[1]*2.)))

                # Save station list and info to xml file
                rec_cat.write(f_nam3,format="STATIONXML")
        except Exception as e:
            print(e)
            print('   No stations found for event',src_cat[j].origins[0].time)
            continue

        # Count number of stations in inventory
        nb_sta = 0
        for k in range(len(rec_cat)):
            nb_sta += len(rec_cat[k])


#-----------------------------------------------------#
# Continue to download if enough stations are present #
#-----------------------------------------------------#

        # Continue if not enough stations (2 steps)
        if nb_sta < min_st:
            continue
        print('  ',j+1,'/',len(src_cat), end='')
        print('   Found', nb_sta,'stations for event',str(src_cat[j].origins[0].time)[:19], end='', flush=True)
        if nb_sta < max_st:
            print()
            continue

        # If enough stations, fetch data from the routing client
        if proc_yn:
            bulkrq = []
            interm = time.time()

            # Build the bulk request query
            for k in range(len(rec_cat)):
                for l in range(len(rec_cat[k])):
                    times3  = [ src_cat[j].origins[0].time -  400 , 
                                src_cat[j].origins[0].time + 3400 ]
                    bulkrq.append([ rec_cat[k].code, rec_cat[k][l].code, "*",
                                    rec_cat[k][l].channels[0].code[:2] + "*",
                                    times3[0], times3[1] ])

            # Download (or load) the data from the routing client
            try:
                f_nam2 = dat_fo + str(src_cat[j].origins[0].time)[:19] + '-raw.PICKLE'
                if from_disk:
                    st = read(f_nam2,format='PICKLE')
                    #print(st.__str__(extended=True))
                else:
                    st = Rclient.get_waveforms_bulk(bulkrq, minimumlength=3600)
                    st.merge(method=1,fill_value='interpolate',interpolation_samples=-1)
                    st.write(f_nam2,format='PICKLE')

                # ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ 
                if test_yn:
                    st = st.select(network=test_ar)
                    print('            [ only taking stations from "'+test_ar+'" ]')
                else:
                    print()
                # ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ 

                    # Raise an error on purpose if less than 3 traces in stream (<1 full station)
                    if len(st)<3:
                        print('                  ... exactly zero data were downloaded')
                        st.rotate('NE->RT')
                n_raw_ev = int(len(st)/3)

            # Go to next event if an error occured
            except Exception as e: 
                print(e)
                print('                  ... error - source skipped!')
                continue

            # Talk to the crowd
            origin = int(len(st)/3)
            print('                  ... downloaded ('+str(origin)+')' \
                 +'    ['+"{:.2f}".format(time.time()-interm)+' s]', flush=True)
            interm = time.time()

            # Go to next event if in "download only" mode
            if only_dl:
                continue


#---------------------------#
# Start processing the data #
#---------------------------#

            # Process each trace individually to detect any potential error
            prblm = []
            doubl = []
            s_lst = []
            for tr in st:
                try:

                    # Get station info
                    s_nam = tr.stats.network + tr.stats.station
                    s_lst.append(s_nam)
                    prsnt = False
                    for k in range(len(rec_cat)):
                        if prsnt == True:
                            break
                        for l in range(len(rec_cat[k])):
                            c_nam = rec_cat[k].code + rec_cat[k][l].code
                            if s_nam == c_nam:  
                                s_lat = rec_cat[k][l].latitude
                                s_lon = rec_cat[k][l].longitude
                                s_net = k
                                prsnt = True
                                break
                    if not prsnt:
                        print(s_nam,'not present')
                        continue

                    # Compute dist, az, baz
                    e_lat = src_cat[j].origins[0]['latitude' ]
                    e_lon = src_cat[j].origins[0]['longitude']
                    e_dep = src_cat[j].origins[0]['depth'    ] / 1000
                    dist, az, baz = geodetics.gps2dist_azimuth(e_lat, e_lon, s_lat, s_lon)
                    dist = dist / (6371.e3 * np.pi / 180.)

                    # Compute travel times
                    if not hasattr(tr.stats, 'traveltimes'):
                        tr.stats.traveltimes = dict()
                    ttim = mod.get_travel_times(source_depth_in_km = e_dep,
                                                distance_in_degree = dist ,
                                                phase_list         = ph_plt)
                    for k in range(len(ttim)):
                        if ttim[k].purist_dist < 3.14:    # To avoid 'far side' SKKS
                            tr.stats.traveltimes[ttim[k].phase.name] = ttim[k].time

                    # Compute position of CMB pierce points
                    if not hasattr(tr.stats, 'piercepoints'): 
                        tr.stats.piercepoints = dict() 
                    ppnt = mod.get_ray_paths_geo(source_depth_in_km        = e_dep,
                                                 source_latitude_in_deg    = e_lat,
                                                 source_longitude_in_deg   = e_lon,
                                                 receiver_latitude_in_deg  = s_lat,
                                                 receiver_longitude_in_deg = s_lon,
                                                 phase_list                = ph_plt)
                    for k in range(len(ppnt)):
                        if ppnt[k].purist_dist < 3.14:    # To avoid 'far side' SKKS
                            p1=np.where(np.array([*ppnt[k].path.tolist()])[:,3] >=  modcmb        )[0]  # Index of pierce point
                            p2=np.where(np.array([*ppnt[k].path.tolist()])[:,3] >= (modcmb-deldep))[0]  # 150km above pierce point 
                            p3=[[ppnt[k].path[p1[-1]][4],ppnt[k].path[p1[-1]][5]],
                                [ppnt[k].path[p2[-2]][4],ppnt[k].path[p2[-2]][5]]]                      # lat/lon positions of p1 and p2
                            tr.stats.piercepoints[ppnt[k].phase.name] = p3

                    # Add metadata to the trace
                    tr.stats['evla'] = e_lat
                    tr.stats['evlo'] = e_lon
                    tr.stats['evdp'] = e_dep
                    tr.stats['stla'] = s_lat
                    tr.stats['stlo'] = s_lon
                    tr.stats['dist'] = dist
                    tr.stats['az']   = az
                    tr.stats['baz']  = baz
                    tr.stats.back_azimuth = baz
                    tr.stats['eventtime'] = src_cat[j].origins[0].time

                    # Decimate and trim for faster operation on time series
                    tr.trim(starttime = src_cat[j].origins[0].time -  300, 
                            endtime   = src_cat[j].origins[0].time + 3300)
                    decim = int(tr.stats.sampling_rate/s_rate)
                    while decim > 10:       # Does not handle decim>16
                        tr.decimate(10)
                        decim = int(tr.stats.sampling_rate/s_rate)
                    if decim > 1:
                        tr.decimate(decim)

                    # Remove the instrument response
                    tr.remove_response(inventory=rec_cat, output=dat_typ)

                # If anything went wrong, add station to list of problematic stations
                except Exception as e:
                    prblm.append(s_nam)
                    #print(e)
                    pass

#---------------------------#
# Proceed to general checks #
#---------------------------#

            # Mark stations with missing components
            for sta in list(dict.fromkeys(s_lst)):
                if   s_lst.count(sta)  < 3:         # Missing components
                    prblm.append(sta)
                elif s_lst.count(sta) == 6:         # Two instruments for one station
                    doubl.append(sta)
                elif s_lst.count(sta) != 3:         # More than 2 instruments or other problem
                    prblm.append(sta)

            # Mark stations with incorrect number of samples (3600s is 1h)
            for sta in list(dict.fromkeys(s_lst)):
                tmp = st.select(network=sta[:2], station=sta[2:])
                if len(tmp) == 0:                   # For networks with only one letter
                    tmp  = st.select(network=sta[:1], station=sta[1:])
                for k in range(len(tmp)-1):
                    if tmp[k].stats.npts != tmp[k+1].stats.npts:
                        prblm.append(sta)           # Incoherent number of samples
                    if tmp[k].stats.npts < 3600*tmp[k].stats.sampling_rate:
                        prblm.append(sta)           # Not long enough

            # Mark station with uncoherent channel naming (ex. 'Z,1,E' or 'Z,2,3')
            for sta in list(dict.fromkeys(s_lst)):
                tmp  = st.select(network=sta[:2], station=sta[2:])
                if len(tmp) == 0:                   # For networks with only one letter
                    tmp  = st.select(network=sta[:1], station=sta[1:])
                channels = []
                for k in range(len(tmp)):
                    channels.append(tmp[k].stats.channel[2])
                if ( any(x in channels for x in ['1','2']) and \
                     any(x in channels for x in ['N','E']) ):
                    prblm.append(sta)
                if ( any(x in channels for x in ['3']) and \
                     any(x in channels for x in ['Z']) ):
                    prblm.append(sta)

            # Remove problematic stations
            for tr in st:
                s_nam = tr.stats.network+tr.stats.station
                if s_nam in prblm:
                    st.remove(tr)
                elif s_nam in doubl:
                    if tr.stats.location != '00':
                        st.remove(tr)               # Only one of both instruments


#-------------------------#
# Finalize the processing #
#-------------------------#

            # Filter, downsample and rotate
            st.sort()
            st.filter('bandpass'          ,
                      freqmin   = f_mini  ,
                      freqmax   = s_rate/2,
                      corners   = 4       ,
                      zerophase = True)
            st.detrend()
            st.resample(s_rate)    

            # Go from (1,2) to (N,E) and then (R,T)
            st.rotate('->ZNE', inventory=rec_cat)
            st.rotate('NE->RT')
            finals = int(len(st)/3)

            # Save the data
            f_name = dat_fo + str(src_cat[j].origins[0].time)[:19] + '-pro.PICKLE'
            st.write(f_name,format='PICKLE')

            # Talk to the crowd
            print('                  ... processed ('+str(finals)+')' \
                 +'     ['+"{:.2f}".format(time.time()-interm)+' s]', flush=True)
        interm = time.time()


#--------------------------------------------#
# Run instaseis to obtain acurate synthetics #
#--------------------------------------------#
        if synt_yn:

            # Load processed data if not just processed
            if not proc_yn:
                print()
                f_name = dat_fo + str(src_cat[j].origins[0].time)[:19] + '-pro.PICKLE'
                st = read(f_name,format='PICKLE')

                # ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
                if test_yn:
                    st = st.select(network=test_ar)
                # ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~

            # Load the source mechanism
            tim    = str(src_cat[j].origins[0].time)[:19]
            ev_tim = int( int(tim[0:4]) * 1e8 + int(tim[5:7])   * 1e6 \
                       + int(tim[8:10]) * 1e4 + int(tim[11:13]) * 1e2 + int(tim[14:16]) * 1e0)

            # CMT times might differ slightly from IRIS, so try +- 1 minute
            try:
                cur_fi = cmt_fo + wor_fo + 'CMT_' + str(ev_tim)
                cmtsrc = obspy.read_events(cur_fi)
            except:
                try:
                    cur_fi = cmt_fo + wor_fo + 'CMT_' + str(ev_tim-1)
                    cmtsrc = obspy.read_events(cur_fi)
                except:
                    try:
                        cur_fi = cmt_fo + wor_fo + 'CMT_' + str(ev_tim+2)
                        cmtsrc = obspy.read_events(cur_fi)
                    except:
                        print('CMT solution not found!')
                        continue

            # Initialise instaseis
            is_src = instaseis.Source(latitude   = cmtsrc[0].origins[0].latitude,
                                      longitude  = cmtsrc[0].origins[0].longitude,
                                      depth_in_m = cmtsrc[0].origins[0].depth,
                                      m_rr = cmtsrc[0].focal_mechanisms[0].moment_tensor.tensor.m_rr,
                                      m_tt = cmtsrc[0].focal_mechanisms[0].moment_tensor.tensor.m_tt,
                                      m_pp = cmtsrc[0].focal_mechanisms[0].moment_tensor.tensor.m_pp,
                                      m_rt = cmtsrc[0].focal_mechanisms[0].moment_tensor.tensor.m_rt,
                                      m_rp = cmtsrc[0].focal_mechanisms[0].moment_tensor.tensor.m_rp,
                                      m_tp = cmtsrc[0].focal_mechanisms[0].moment_tensor.tensor.m_tp,
                                      origin_time=src_cat[j].origins[0].time)

            # Create the stream structure
            sy = st.copy()
            sy.clear()

            # Create synthetics trace by trace
            for tr in st:
                if tr.stats.channel[2] == 'Z':
                    s_lat  = tr.stats['stla']
                    s_lon  = tr.stats['stlo']
                    baz    = tr.stats['baz']
                    is_rcv = instaseis.Receiver(latitude  = s_lat,
                                                longitude = s_lon,
                                                network   = tr.stats['network'],
                                                station   = tr.stats['station'])
                    synths = gf_dat.get_seismograms(source=is_src, receiver=is_rcv, kind=syn_typ, dt=1/s_rate)
                    for k in range(len(synths)):
                        synths[k].stats.back_azimuth = baz
                    sy += synths

            # Rotate traces to match processed data
            sy.rotate('NE->RT')

            # Save the data
            finals = int(len(st)/3)
            f_nam4 = dat_fo + str(src_cat[j].origins[0].time)[:19] + '-syn.PICKLE'
            sy.write(f_nam4,format='PICKLE')

            # Talk to the crowd
            print('                  ... synthesized ('+str(finals)+')' \
                 +'   ['+"{:.2f}".format(time.time()-interm)+' s]', flush=True)
        interm = time.time()


#----------------------------------------#
# Plot map and data for promising events #
#----------------------------------------#
        if maps_yn:

            # Load data if not already in memory from processing
            if (not proc_yn) and (not synt_yn):
                print()
            if not proc_yn:
                f_name  = dat_fo + str(src_cat[j].origins[0].time)[:19] + '-pro.PICKLE'
                st = read(f_name,format='PICKLE')
            if not synt_yn:
                f_nam4  = dat_fo + str(src_cat[j].origins[0].time)[:19] + '-syn.PICKLE'
                sy = read(f_nam4,format='PICKLE')

            # ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
            if len(keep_ar) > 0:
                print('                  < keeping stations from',keep_ar,'>')
                for tr in st:
                    if tr.stats.network not in keep_ar:
                        st.remove(tr)
            if len(remv_ar) > 0:
                print('                  < removing stations from',remv_ar,'>')
                for tr in st:
                    if tr.stats.network in remv_ar:
                        st.remove(tr)
            # ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~

            # List all the active stations for the event
            active = []
            net_na = 'XXX'
            net_id = -1
            for tr in st:
                if tr.stats.channel[2] == 'Z':
                    if tr.stats.network != net_na:
                        net_na  = tr.stats.network
                        net_id += 1
                    s_lat = tr.stats['stla']
                    s_lon = tr.stats['stlo']
                    s_net = net_id
                    active.append([s_lat, s_lon, s_net])
            ev_pos = [src_cat[j].origins[0].latitude, src_cat[j].origins[0].longitude]

            # Initialize arrays for plot info
            azi_ls = []
            dis_ls = []
            latlo2 = []
            latlon = []
            raypat = [[0]]
            pilalo = []
            pll_sk = []
            pll_kk = []
            cmbtop = [[0]]
            cmb_sk = [[0]]
            cmb_kk = [[0]]

            # Load source mechanism
            tim = str(src_cat[j].origins[0].time)[:19]
            ev_tim = int( int(tim[0:4]) * 1e8 + int(tim[5:7])   * 1e6 \
                       + int(tim[8:10]) * 1e4 + int(tim[11:13]) * 1e2 + int(tim[14:16]) * 1e0)
            foundd = False
            for k in [-1, 0, 1]:      # Same thing as before with CMT vs. IRIS times
                try:
                    cur_fi = cmt_fo + wor_fo + 'CMT_' + str(ev_tim+k)
                    cmtsrc = obspy.read_events(cur_fi)
                    foundd = True
                except:
                    pass
            if not foundd:
                print('CMT solution not found!')
                continue

            # Go from moment tensor to radiation pattern
            e_dep  = cmtsrc[0].origins[0].depth / 1000
            mt     = cmtsrc[0].focal_mechanisms[0].moment_tensor.tensor
            mo_ten = MomTen(mt.m_rr, mt.m_tt, mt.m_pp, mt.m_rt, mt.m_rp, mt.m_tp, 1)
            nodals = mt2plane(mo_ten)
            takeof = mod.get_travel_times(source_depth_in_km   = e_dep, 
                                          distance_in_degree   = 105,
                                          receiver_depth_in_km = 0. ,
                                          phase_list           = [phofin] )[0].takeoff_angle
            theta     = np.linspace(0,360,361)
            P,S,SH,SV = radiation.rpgen(nodals.strike, nodals.dip, nodals.rake, 0, 0.25, [takeof], theta)

            # List all "potential" stations info, i.e. all available but not necessarily downloaded data
            for k in range(len(rec_cat)):
                for l in range(len(rec_cat[k])):
                    sla = rec_cat[k][l].latitude
                    slo = rec_cat[k][l].longitude
                    sco = k
                    latlo2.append(np.array([sla, slo, k]))

            # Compute ray paths for stations with data
            for k in range(len(active)):
                    sla = active[k][0]
                    slo = active[k][1]
                    sco = active[k][2]
                    latlon.append(np.array([sla, slo, sco]))
                    try:

                        # Ray paths
                        t_ph = ph_plt.copy()
                        t_ph.append('SKIKS')        # For long  distances when SKS   is not found
                        t_ph.append('S')            # For short distances when Sdiff is not found
                        temp = mod.get_ray_paths_geo(source_depth_in_km        = src_cat[j].origins[0].depth/1000,
                                                     source_latitude_in_deg    = src_cat[j].origins[0].latitude,
                                                     source_longitude_in_deg   = src_cat[j].origins[0].longitude,
                                                     receiver_latitude_in_deg  = sla,
                                                     receiver_longitude_in_deg = slo,
                                                     phase_list                = t_ph)

                        # Check if station is in Sdiff range
                        pha_li = []
                        pha_nu = []
                        sd=99
                        sk=99
                        kk=99
                        for l in range(len(temp)):
                            if temp[l].purist_dist < 3.14: 
                                pha_li.append(temp[l].phase.name)
                                pha_nu.append(l)
                            # SKKS should always be there...
                        if 'SKKS' in pha_li:
                            kk = pha_nu[pha_li.index('SKKS')]
                            # SKS (closer) of SKIKS (further)
                        if 'SKS' in pha_li:
                            sk = pha_nu[pha_li.index('SKS')]
                        else:
                            sk = pha_nu[pha_li.index('SKIKS')]
                            # S (closer) or Sdiff (further)
                        if 'Sdiff' in pha_li:
                            sd = pha_nu[pha_li.index('Sdiff')]
                            ss = False
                        elif 'S' in pha_li:
                            sd = pha_nu[pha_li.index('S')]
                            ss = True
                            # Go to next if too far
                        else:
                            continue

                        # Pierce points and travel times
                                # Sdiff
                        if not ss:
                            pierce=np.where(np.array([*temp[sd].path.tolist()])[:,3] >=  modcmb        )[0] #== 2891.5)[0]
                            pierc2=np.where(np.array([*temp[sd].path.tolist()])[:,3] >= (modcmb-deldep))[0] #>= 2741.5)[0]
                            raypat.append(np.array(temp[sd].path.tolist())[:,4:])
                            cmbtop.append(np.array(temp[sd].path.tolist())[pierce[-1]:pierc2[-1],4:])
                            pilalo.append(np.array([temp[sd].path[pierce[-1]][4],temp[sd].path[pierce[-1]][5],
                                                    temp[sd].path[pierc2[-2]][4],temp[sd].path[pierc2[-2]][5]]))
                        if ss:
                            raypat.append(np.array(temp[sd].path.tolist())[:,4:])
                            cmbtop.append(np.array([[0,0],[0,0]]))
                            pilalo.append(np.array([0,0,0,0]))
                                # SKS
                        pi_ske=np.where(np.array([*temp[sk].path.tolist()])[:,3] >=  modcmb        )[0]
                        pi_sk2=np.where(np.array([*temp[sk].path.tolist()])[:,3] >= (modcmb-deldep))[0]
                        cmb_sk.append(np.array(temp[sk].path.tolist())[pi_ske[-1]:pi_sk2[-1],4:])
                        pll_sk.append(np.array([temp[sk].path[pi_ske[-1]][4],temp[sk].path[pi_ske[-1]][5],
                                                temp[sk].path[pi_sk2[-2]][4],temp[sk].path[pi_sk2[-2]][5]]))
                                # SKKS
                        pi_kke=np.where(np.array([*temp[kk].path.tolist()])[:,3] >=  modcmb        )[0]
                        pi_kk2=np.where(np.array([*temp[kk].path.tolist()])[:,3] >= (modcmb-deldep))[0]
                        cmb_kk.append(np.array(temp[kk].path.tolist())[pi_kke[-1]:pi_kk2[-1],4:])
                        pll_kk.append(np.array([temp[kk].path[pi_kke[-1]][4],temp[kk].path[pi_kke[-1]][5],
                                                temp[kk].path[pi_kk2[-2]][4],temp[kk].path[pi_kk2[-2]][5]]))
                    except Exception as e:
                        print(i,j,k,'has an error:')
                        print(e)
                        pass

            # Go from lists to arrays
            latlo2 = np.array(latlo2)
            latlon = np.array(latlon)
            raypat = np.array(raypat)
            pilalo = np.array(pilalo)
            cmbtop = np.array(cmbtop)
            pll_sk = np.array(pll_sk)
            cmb_sk = np.array(cmb_sk)
            pll_kk = np.array(pll_kk)
            cmb_kk = np.array(cmb_kk)

            # Additional data processing for smooth plotting
            st2 = st.copy()
            st2.filter('bandpass'           ,
                       freqmin   = f_plot[0],
                       freqmax   = f_plot[1],
                       corners   = 4       ,
                       zerophase = True)
            sy2 = sy.copy()
            sy2.filter('bandpass'           ,
                       freqmin   = f_plot[0],
                       freqmax   = f_plot[1],
                       corners   = 4       ,
                       zerophase = True)

            # Separate into radial and transerve streams
            st2R = st2.select(channel='*R') #'*1') #
            st2T = st2.select(channel='*T') #'*2') #
            sy2R = sy2.select(channel='*R') #'*1') #
            sy2T = sy2.select(channel='*T') #'*2') #

            # Start preparing for the plot
            if not simple_in:
                clon = map_lon
                clat = map_lat
                wplt = 2.8e7 / 2.3
            else:
                cent = pilalo[pilalo[:,0]!=0]
                clon = np.mean(cent[:,1])
                clat = np.mean(cent[:,0]) 
                wplt = geodetics.gps2dist_azimuth(ev_pos[0], ev_pos[1], clat, clon)[0]
            proj = 'aeqd'                           # Basemap projection
            rndm = np.min([2.3*wplt,2.8e7])         # Size of Basemap instance (2.3 looked nice, feel free to change)
            rnyn = True                             # Round or square Basemap
            meridians = np.arange(-360.,361.,20.)
            parallels = np.arange( -80., 81.,20.)

            # Open figure
            fig1 = plt.figure(1,figsize=(28,16),dpi=200)
            grds = GridSpec(8,14,wspace=.40,hspace=1.)    # Workaround for more compact plot, not entirely satisfying...

            # FIRST PLOT THE MAP
                    # The map itself
            #plt.subplot(grds[:4,:4])
            fig1.add_subplot(grds[:4,:4])
            m1 = Basemap(projection = proj, resolution = 'l' , area_thresh = 10000,
                         lon_0      = clon, lat_0      = clat, width       = rndm , height = rndm, round = rnyn)
            m1.scatter(rotm, ratm, c=mlay, s=50, cmap=RGBl, marker='s', linewidth=0, latlon=True, rasterized=True, alpha=.11) # Vote map
            m1.drawcoastlines(color='#2e2e2e', linewidth=.5, zorder=2)
            m1.drawmeridians(meridians, linewidth=.4) #, labels=[True,True,True,True])
            m1.drawparallels(parallels, linewidth=.4) #, labels=[True,True,True,True])
                    # A workaround for when both poles are on the map...
            prl_1 = np.arange(-360,361, 1.)
            prl_2 = np.arange( -80, 81,20.)
            for line in prl_2:
                prl_line = np.ones(len(prl_1)) * line
                m1.plot(prl_1, prl_line, ":k", latlon=True, linewidth=.4)

                    # The events, stations and pierce points
            m1.scatter(ev_pos[  1], ev_pos[  0], c='y'        , edgecolors='k', latlon=True , s= 100, zorder=10, marker='*')
            m1.scatter(pll_sk[:,1], pll_sk[:,0], c='k'        , linewidth=.1  , latlon=True , s=   1, zorder=10, marker='+')
            m1.scatter(pll_kk[:,1], pll_kk[:,0], c='k'        , linewidth=.1  , latlon=True , s=   1, zorder=10, marker='x')
            m1.scatter(pilalo[:,1], pilalo[:,0], c='g'        , edgecolors='k', latlon=True , s=   3, zorder=10, linewidth=.1)
            m1.scatter(pilalo[:,3], pilalo[:,2], c='k'        , edgecolors='k', latlon=True , s=  .5, zorder=11, linewidth=.1)
            m1.scatter(latlo2[:,1], latlo2[:,0], c='w'        , edgecolors='w', latlon=True , s=   1, zorder=10)
            m1.scatter(latlon[:,1], latlon[:,0], c='w'        , edgecolors='w', latlon=True , s=   3, zorder=10)
            m1.scatter(latlo2[:,1], latlo2[:,0], c=latlo2[:,2], edgecolors='k', latlon=True , s=   2, zorder=10,
                                                                cmap='nipy_spectral'        , linewidth=.2, alpha=.1)
            m1.scatter(latlon[:,1], latlon[:,0], c=latlon[:,2], edgecolors='w', latlon=True , s=   2, zorder=10,
                                                                cmap='nipy_spectral'        , linewidth=.2)
            if not simple_in:     # Circle around region of interest (Perm here)
                m1.scatter(clon, clat , c='None' , marker='o' , edgecolors='r', latlon=True , s= 800, zorder= 9) #1300

                    # The raypaths
            for k in range(1,len(raypat)):
                m1.plot(raypat[k][:,1], raypat[k][:,0], c='k' , zorder=1      , latlon=True , linewidth=.05)
            for k in range(1,len(cmbtop)):
                m1.plot(cmbtop[k][:,1], cmbtop[k][:,0], c='m'      , zorder=4      , latlon=True , linewidth=.15)
                m1.plot(cmb_sk[k][:,1], cmb_sk[k][:,0], c='orange' , zorder=2      , latlon=True , linewidth=.15)
                m1.plot(cmb_kk[k][:,1], cmb_kk[k][:,0], c='lime'   , zorder=3      , latlon=True , linewidth=.15)

            # THEN PLOT THE INFORMATION
            fig1.add_subplot(grds[0,6])
            plt.gca().axis('off')
            plt.text(-.2,.80,'date: ' + str(st2[0].stats['eventtime'])[ 0:10],fontsize=12,fontname='monospace')
            plt.text(-.2,.60,'time: ' + str(st2[0].stats['eventtime'])[11:19],fontsize=12,fontname='monospace')
            plt.text(-.2,.40,'lat : ' + str(st2[0].stats['evla'])            ,fontsize=12,fontname='monospace')
            plt.text(-.2,.20,'lon : ' + str(st2[0].stats['evlo'])            ,fontsize=12,fontname='monospace')
            plt.text(-.2,.00,'dep : ' + str(st2[0].stats['evdp'])            ,fontsize=12,fontname='monospace')
            plt.text(-.2,-.2,'mag : ' + str(cmtsrc[0].magnitudes[0]['mag'])  ,fontsize=12,fontname='monospace')
            plt.xlim([0,1])
            plt.ylim([0,1])
            plt.title('source information')

            # MOVE ON TO THE DATA
            for cur_ph in ph_plt:
                        # Automatic positioning on gridspec
                if cur_ph == 'Sdiff':
                    xpos = 7
                    ypos = 0
                    colr = 'm'
                if cur_ph == 'SKS':
                    xpos = 0
                    ypos = 4
                    colr = 'orange'
                if cur_ph == 'SKKS':
                    xpos = 7
                    ypos = 4
                    colr = 'lime'

                        # Select the component with the current phase data
                tshift = UTCDateTime(st2[0].stats['starttime']) - st2[0].stats['eventtime']
                data_t = st2R if cur_ph in ['SKS', 'SKKS'] else st2T
                data_y = sy2R if cur_ph in ['SKS', 'SKKS'] else sy2T

                        # Plot the traces one by one
                for k in range(len(data_t)):
                    tr = data_t[k]
                    ty = data_y[k]

                        # Compute time relative to theoretical arrival
                    try:
                        tmstmp = np.array(tr.times() + tshift - tr.stats.traveltimes[cur_ph])
                        tmstm2 = np.array(ty.times() + tshift - tr.stats.traveltimes[cur_ph] + 300)   # Data start 5min before event
                        window = np.array([x for x in range(len(tmstmp)) if (tmstmp[x]>x_lims[0] and tmstmp[x]<x_lims[1])])
                        windo2 = np.array([x for x in range(len(tmstm2)) if (tmstm2[x]>x_lims[0] and tmstm2[x]<x_lims[1])])
                        if (len(window)==0) or (len(windo2)==0):
                            continue
                        center = np.argmin(abs(tmstmp))
                    except Exception as e:
                        #print(e)
                        continue

                        # Compute normalisation factor
                    norm_t = factor * np.max(abs(tr.data[window]))
                    norm_y = factor * np.max(abs(ty.data[windo2]))
                    if (norm_t==0) or (norm_y==0):
                        continue

                        # Put in correct distance box (5 in total, each spanning 15 deg, plus particle motion)
                    azi_ls.append(tr.stats['az'])
                    dis_ls.append(tr.stats['dist'])
                    if (tr.stats['dist'] >=  80) and (tr.stats['dist'] <=  95):
                        fig1.add_subplot(grds[ypos:ypos+4,xpos+0])
                    if (tr.stats['dist'] >=  95) and (tr.stats['dist'] <= 110):
                        fig1.add_subplot(grds[ypos:ypos+4,xpos+1])
                    if (tr.stats['dist'] >= 110) and (tr.stats['dist'] <= 125):
                        fig1.add_subplot(grds[ypos:ypos+4,xpos+2])
                    if (tr.stats['dist'] >= 125) and (tr.stats['dist'] <= 140):
                        fig1.add_subplot(grds[ypos:ypos+4,xpos+3])
                    if (tr.stats['dist'] >= 140) and (tr.stats['dist'] <= 155):
                        fig1.add_subplot(grds[ypos:ypos+4,xpos+4])
                    if (tr.stats['dist'] <=  80)  or (tr.stats['dist'] >= 155):
                        continue         # Outside of reasonable Sdiff range
                    plt.plot(tmstmp,tr.data/norm_t+tr.stats['az'],'-k'      ,linewidth=.20,zorder=20,alpha=1.0)
                    plt.plot(tmstm2,ty.data/norm_y+tr.stats['az'],color=colr,linewidth=.20,zorder=10,alpha=0.2)
                    if (tr.stats['dist'] >=  80) and (tr.stats['dist'] <= 155): #135
                        fig1.add_subplot(grds[ypos:ypos+4,xpos+5:xpos+7])
                        plt.plot(st2R[k].data[center-50:center+150]/norm_t+tr.stats['dist'],
                                 st2T[k].data[center-50:center+150]/norm_t+tr.stats['az']  ,
                                 '-k',linewidth=.2)

            # ANNOTATE ALL THE PLOTS
            pad = 2
            y_lims = [min(azi_ls)-pad,max(azi_ls)+pad]

                    # The data plots
            for k in [0,1,2,3,4,5,7,8,9,10,11,12]:
                for l in [0,4]:
                    if (l==0 and k<6):
                        continue
                    if (k==5 or k==12):
                        fig1.add_subplot(grds[l:l+4,k:k+2])
                        plt.title('particle motion')
                        plt.ylim(y_lims)
                        plt.gca().yaxis.set_major_locator(MaxNLocator(integer=True))
                        plt.gca().xaxis.set_major_locator(MaxNLocator(integer=True))
                        continue
                    else:
                        fig1.add_subplot(grds[l:l+4,k])
                    if   (k==0 or k==7):
                        plt.title('80~95 deg')
                        plt.gca().axes.yaxis.set_ticklabels([])
                    elif (k==1 or k==8):
                        plt.title('95~110 deg')
                    elif (k==2 or k==9):
                        plt.title('110~125 deg')
                    elif (k==3 or k==10):
                        plt.title('125~140 deg')
                    elif (k==4 or k==11):
                        plt.title('140~155 deg')
                    plt.plot((0,0),(y_lims[0],y_lims[1]),color='grey',linewidth=.5)
                    for m in range(x_lims[0],x_lims[1],10):
                        plt.plot((m,m),(y_lims[0],y_lims[1]),color='grey',linewidth=.1)
                    plt.xlim(x_lims)
                    plt.ylim(y_lims)
                    plt.gca().yaxis.set_major_locator(MaxNLocator(integer=True))
                    plt.gca().yaxis.set_ticks_position('both')

                    # The phase descriptor boxes
            fig1.add_subplot(grds[1,6])
            plt.gca().axis('off')
            plt.text( .2,.5,'Sdiff',fontsize=24)
            plt.arrow(.3,.3,.3,.0,linewidth=3,head_width=.1)
            plt.xlim([0,1])
            plt.ylim([0,1])
            fig1.add_subplot(grds[2,6])
            plt.gca().axis('off')
            plt.text(.2,.5,'SKS',fontsize=24)
            plt.arrow(.6,.3,-.2,-.6,linewidth=2.5,head_width=.11)
            plt.xlim([  0,1])
            plt.ylim([-.8,1])
            fig1.add_subplot(grds[3,6])
            plt.gca().axis('off')
            plt.text(.2,.5,'SKKS',fontsize=24)
            plt.arrow(.4,.3, .2,-.6,linewidth=2.5,head_width=.11)
            plt.xlim([  0,1])
            plt.ylim([-.8,1])

            # FINALLY THE RADIATION PATTERNS
                    # Both
            SV_plt = SV[0]
            SH_plt = SH[0]
            length = np.max([np.max(np.abs(SV_plt)),np.max(np.abs(SH_plt))])*1.1 
                    # Sv
            fig1.add_subplot(grds[0:2,4:6], projection='polar')
            plt.plot(np.radians(theta[SV_plt>0]), np.abs(SV_plt[SV_plt>0]),'-r',zorder=2)
            plt.plot(np.radians(theta[SV_plt<0]), np.abs(SV_plt[SV_plt<0]),':b',zorder=2)
            for k in range(len(azi_ls)):
                plt.plot((0,np.radians(azi_ls[k])),(0,length),'-k',linewidth=.01,zorder=3)
                plt.plot((0,np.radians(azi_ls[k])),(0,length),'-k',linewidth=.10,zorder=1)
            plt.title('SV                       ',fontsize=24)
            plt.gca().set_theta_zero_location('N')
            plt.gca().set_theta_direction(-1)
            plt.gca().set_yticklabels([])
            plt.gca().set_rmin(0)
                    # Sh
            fig1.add_subplot(grds[2:4,4:6], projection='polar')
            plt.plot(np.radians(theta[SH_plt>0]), np.abs(SH_plt[SH_plt>0]),'-r',zorder=2)
            plt.plot(np.radians(theta[SH_plt<0]), np.abs(SH_plt[SH_plt<0]),':b',zorder=2)
            for k in range(len(azi_ls)):
                plt.plot((0,np.radians(azi_ls[k])),(0,length),'-k',linewidth=.01,zorder=3)
                plt.plot((0,np.radians(azi_ls[k])),(0,length),'-k',linewidth=.10,zorder=1)
            plt.title('SH                       ',fontsize=24)
            plt.gca().set_theta_zero_location('N')
            plt.gca().set_theta_direction(-1)
            plt.gca().set_yticklabels([])
            plt.gca().set_rmin(0)

            # LAST BITS AND BOBS
            plt.tight_layout(pad=1)
            plt.savefig(plt_fo + sub_fo + str(src_cat[j].origins[0].time)[:19] + '.png',bbox_inches='tight')
            plt.clf()
            plt.cla()
            plt.close()

            # Talk to the crowd
            print('                  ... plotted ' \
                 +'           ['+"{:.2f}".format(time.time()-interm)+' s]', flush=True)
            interm = time.time()
        #print()
        
    # Talk to the crowd
    print('               ', end='')
    print('   time =', time.strftime("%Y-%m-%d_%H:%M:%S", time.localtime()),'   ', 
          'runtime =', "{:.2f}".format(time.time()-starts), 's')
    print()
print()
print('  Done!')
print()
