#1/usr/bin/bash

the_time=`date +"%Y-%m-%d-%T"`
echo
echo '              '$the_time
./deep_phase_tester.py 2> logs/$the_time.log
